#include "backupfile.h"
#include <stdbool.h>
extern char *backupfile_internal (int, char const *, enum backup_type, bool);
