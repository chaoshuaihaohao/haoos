#include <config.h>
#define GL_XSUBLIST_INLINE _GL_EXTERN_INLINE
#include "gl_xsublist.h"
