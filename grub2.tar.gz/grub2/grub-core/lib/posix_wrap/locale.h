#ifdef GRUB_UTIL
#include_next <locale.h>
#endif
