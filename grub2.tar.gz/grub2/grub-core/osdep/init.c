#if defined (__MINGW32__)
#include "windows/init.c"
#else
#include "basic/init.c"
#endif
